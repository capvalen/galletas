<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cajaDetalle extends Model
{
    //
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class unidades extends Model
{
    //
}

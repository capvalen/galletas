<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class monedas_proceso extends Model
{
    //
}

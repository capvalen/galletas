<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class proveedores extends Model
{
    //
}

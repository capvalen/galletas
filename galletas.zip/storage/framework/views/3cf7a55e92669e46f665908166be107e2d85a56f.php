<?php $__env->startSection('css'); ?>
<style>
.custom-file-input ~ .custom-file-label::after {
    content: "Buscar";
}
#cardFormulario label{
margin-top: 10px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
    <li class="breadcrumb-item " aria-current="page"><a href="<?php echo e(route('galeria.mostrar')); ?>">Galerías</a></li>
    <li class="breadcrumb-item active" aria-current="page">Subida foto</li>
  </ol>
</nav>
<h2><i class="icofont-camera"></i> Subir a una galería</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
<form action="<?php echo e(route('galeria.subir')); ?>" method="POST" enctype="multipart/form-data" >
<?php echo csrf_field(); ?>
<div class="card col-md-6" id="cardFormulario">

	<div class="card-body">
		<label for="">Grupo</label>
		<select name="grupo" id="" class="form-control">
			<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($grupo->id); ?>"><?php echo e($grupo->grupo); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<label for="">Tipo de Reporte</label>
		<select name="tipo" id="" class="form-control">
			<?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->descripcion); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<label class="mb-0" for="">Archivo</label>
		<div class="input-group mb-2">
			<div class="custom-file">
				<input type="file" class="custom-file-input m-0" name="archivo" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" accept="image/*, .pdf">
				<label class="custom-file-label" for="inputGroupFile04">Seleccione el archivo</label>
			</div>
		</div>
		<label for="">Observaciones:</label>
		<input type="text" name="observacion" class="form-control" id="">
		<?php if(session('mensaje')): ?>
			<div class="alert alert-success"><?php echo e(session('mensaje')); ?></div>
		<?php endif; ?>

		<button class="btn btn-outline-success btn-block my-3" type="submit"><i class="icofont-upload-alt"></i> Subir archivo</button>
	</div>

</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$('#inputGroupFile04').on('change',function(e){
	//get the file name
	var fileName = $(this).val();
	//replace the "Choose a file" label
	//$(this).next('.custom-file-label').html(fileName);
	$(this).next('.custom-file-label').html(e.target.files[0].name);
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\galletas\resources\views/galeria/subida.blade.php ENDPATH**/ ?>
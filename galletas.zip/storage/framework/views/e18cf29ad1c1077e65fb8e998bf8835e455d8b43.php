namespace App;

<?php $__env->startSection('css'); ?>
<style>
.custom-file-input ~ .custom-file-label::after {
    content: "Buscar";
}
#cardFormulario label{
margin-top: 10px;
}
.card-img-top {
    width: 100%;
    height: 15vw;
    object-fit: cover;
		object-position: top;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo'); ?>
<nav aria-label="breadcrumb" class="d-print-none">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
    <li class="breadcrumb-item active" aria-current="page">Galerías</li>
  </ol>
</nav>
<h2 class="d-print-none"><i class="icofont-camera"></i> Galerías</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
<div class="card col-md-6 d-print-none">
	
	<div class="card-body">
		<h5 class="card-title">Filtros</h5>
		<div class="row ">
			<div class="col col-md-6">
				<label class="d-block" for="">Fecha</label>
				<input type="date" name="fecha" class="form-control d-inline-block col-9" id="txtFecha" value="<?php echo e($fecha); ?>">
				<button class="btn btn-outline-primary" id="btnBuscar"><i class="icofont-search-1"></i> </button>
			</div>
			<div class="col col-md-6 d-flex align-items-end">
				<a class="btn btn-outline-primary" type="button" href="<?php echo e(route('galeria.subida')); ?>"><i class="icofont-folder-open"></i> Subir nuevo reporte</a>
			</div>
		</div>
		
	</div>

</div>

<?php if(isset($contador)): ?>
<?php if(count($contador)>0): ?>
<div class="card mt-2 col-md-6 d-print-none">
	<div class="card-body">
		<p>Resumen:</p>
		<ul class="list-group">
			<?php $__currentLoopData = $contador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="list-group-item  d-flex justify-content-between align-items-center"><a href="<?php echo e(route('galeria.mostrar.grupo', [$fecha, $conta->grupo_id] )); ?>"> <?php echo e($conta->grupo); ?></a> <span class="badge badge-primary badge-pill"><?php echo e($conta->cantidad); ?></span> </li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	
</div>
<?php else: ?>
<p class="mt-4">No se encontraron archivos en: <strong><?php echo e(\Carbon\Carbon::parse($fecha)->format('d/m/Y')); ?></strong></p>
<?php endif; ?>
<?php endif; ?>

<?php if(isset($categorias)): ?>
<div class=" mt-3" id="divPadreCards d-print-none">
	<div class="row row-cols-5">
		<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col">
			<div class="card">
				<img src="<?php if( substr($categoria->foto, -4) =='.pdf'): ?> <?php echo e(url('subidas/iconopdf.png')); ?> <?php else: ?>  <?php echo e(url('subidas/' . $categoria->foto )); ?>  <?php endif; ?>" class="card-img-top" alt="..."data-archivo="<?php echo e($categoria->foto); ?>">
				<div class="card-body">
					<small class="text-muted">Creado el <?php echo e(\Carbon\Carbon::parse($categoria->created_at)->format('d/m/Y h:m a')); ?></small>
					<h5 class="card-title"><?php echo e($categoria->descripcion); ?></h5>
					<p class="card-text"><?php echo e($categoria->observacion); ?></p>
					<a href="<?php echo e(url('subidas/' . $categoria->foto )); ?>" class="btn btn-outline-success" download><i class="icofont-download"></i> Descargar</a>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>

<div id="modalPreview" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
	<div class="modal-dialog modal-xl" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="my-modal-title">Vista previa</h5>
				<button class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div id="relleno">

				</div>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>


<?php $dominio =  preg_replace('/^www\./','',$_SERVER['HTTP_HOST']);?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

$('#txtFecha').keypress(function (e) { 
	if(e.keyCode == 13){ 
		$('#btnBuscar').click();
	}
});
$('#btnBuscar').click(function() {
	if( $('#txtFecha').val()!='' ){
		window.location = "/galeria/mostrar/" + $('#txtFecha').val();
	}
});

$('.card-img-top').click(function() {
	$('#relleno').html('');
	var archivo = $(this).attr('data-archivo');
	var tipo = archivo.substr(-4).toLowerCase();
	if(tipo == '.pdf'){
		$('.modal-body').css('height', '90vh');
		$('#relleno').html( `<embed src="//<?= $dominio; ?>/subidas/${archivo}" width="100%" height="100%" type="application/pdf">` )
	}else{
		$('.modal-body').css('height', '');
		$('#relleno').html(`<center><img class="img-fluid mx-auto" src="//<?= $dominio; ?>/subidas/${archivo}"></center>`);
	}
	
	$('#modalPreview').modal('show');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\galletas\resources\views/galeria/mostrar.blade.php ENDPATH**/ ?>
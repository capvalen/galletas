<?php $__env->startSection('titulo'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
    <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('clientes')); ?>">Clientes</a></li>
    <li class="breadcrumb-item active" aria-current="page">Editar</li>
  </ol>
</nav>
<h2><i class="icofont-users-alt-1"></i> Editar datos del cliente</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>

<div class="card col-6">
  <div class="card-body">
    <label for="">R.U.C.</label>
    <input class="form-control" type="text" name="" value="20602337147">
    <label for="">Razon social</label>
    <input class="form-control" type="text" name="" value="Infocat Soluciones SAC">
    <label for="">Dirección</label>
    <input class="form-control" type="text" name="" value="Av. Huancavelica 435 - El Tambo">
    <label for="">Celular</label>
    <input class="form-control" type="text" name="" value="977692108">
    <label for="">Contacto</label>
    <input class="form-control" type="text" name="" value="Carlos Pariona Valencia">
    <button class="btn btn-outline-warning mt-2 btn-block">Actualizar Cliente</button>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\galletas\resources\views/clientes/editar.blade.php ENDPATH**/ ?>
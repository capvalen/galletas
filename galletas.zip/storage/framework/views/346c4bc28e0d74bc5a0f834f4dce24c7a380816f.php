<?php $__env->startSection('titulo'); ?>
<h2><i class="icofont-ui-home"></i> Inicio</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
<p>Bienvenido al sistema de Fábrica Marie, seleccione el menú y empiece a navegar</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Carlos P\Documents\GitHub\galletas\resources\views/plantillas/inicio.blade.php ENDPATH**/ ?>
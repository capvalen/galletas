@extends('plantillas.panel')

@section('titulo')
<h2><i class="icofont-ui-home"></i> Inicio</h2>
@endsection

@section('cuerpo')
<p>Bienvenido al sistema de Fábrica Marie, seleccione el menú y empiece a navegar</p>
@endsection